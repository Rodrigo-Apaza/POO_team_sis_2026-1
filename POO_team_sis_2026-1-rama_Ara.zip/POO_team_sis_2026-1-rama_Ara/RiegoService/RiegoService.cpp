#include "pch.h"

#include "RiegoService.h"
//DEFINICÍÓN DE MÉTODOS USADOS EN MÉTODOS CRUD PARA PLANTAS 



//DEFINICÍÓN DE MÉTODOS USADOS EN MÉTODOS CRUD PARA USERS

int RiegoService::Service::AddUser(user^ User) {
	return Persistance::SaveUser(User);
}

List<user^>^ RiegoService::Service::GetAllUsers() {
	return Persistance::LoadUser();
}

user^ RiegoService::Service::GetUsersById(int userId) {
	return Persistance::QueryUserById(userId);
}

int RiegoService::Service::UpdateUser(user^ updatedUser) {
	return Persistance::UpdateUser(updatedUser);
}

int RiegoService::Service::DeleteUser(int userId) {
	return Persistance::DeleteUser(userId);
}

//DEFINICÍÓN DE MÉTODOS USADOS EN MÉTODOS CRUD PARA SUELOS

//gente, tratemos de trabajar en un orden secuencial para todos los archivos, 
// de  modo que sea más fácil encontrar algún eror que pueda aparecer en el código ATTE. Aranthza
//Fernando tmb dejó algunas notas en algunos archivos


//DEFINICÍÓN DE MÉTODOS USADOS EN MÉTODOS CRUD PARA HARDWARE



//DEFINICÍÓN DE MÉTODOS USADOS EN MÉTODOS CRUD PARA ingrese_nombre_de_clase