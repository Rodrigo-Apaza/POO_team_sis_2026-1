#pragma once

using namespace System;
using namespace System::Collections::Generic;
using namespace RiegoModel;
using namespace RiegoPersistance;

namespace RiegoService {
	public ref class Service
	{
		// MÉTODOS CRUD - USERS
		static int AddUser(user^ User);
		static List<user^>^ GetAllUsers();
		static user^ GetUsersById(int userId);
		static int UpdateUser(user^ updatedUser);
		static int DeleteUser(int userId);
		
		// MÉTODOS CRUD - SUELOS

		//gente, tratemos de trabajar en un orden secuencial para todos los archivos, 
// de  modo que sea más fácil encontrar algún eror que pueda aparecer en el código ATTE. Aranthza
//Fernando tmb dejó algunas notas en algunos archivos





		// MÉTODOS CRUD - HARDWARE


	};
}
