#pragma once
#include "SueloForm.h"


namespace RiegoGUIApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace RiegoModel;
	using namespace RiegoPersistance;
	using namespace System::Collections::Generic;

	/// <summary>
	/// Resumen de PlantasForm
	/// </summary>
	public ref class PlantasForm : public System::Windows::Forms::Form
	{
	public:
		PlantasForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~PlantasForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ addplantbtn;
	private: System::Windows::Forms::Button^ deleteplantbtn;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ PlantaName;
	private: System::Windows::Forms::Button^ btnIrASuelos;

	protected:

	protected:


	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->addplantbtn = (gcnew System::Windows::Forms::Button());
			this->deleteplantbtn = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->PlantaName = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnIrASuelos = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// addplantbtn
			// 
			this->addplantbtn->Location = System::Drawing::Point(492, 59);
			this->addplantbtn->Margin = System::Windows::Forms::Padding(3, 4, 3, 4);
			this->addplantbtn->Name = L"addplantbtn";
			this->addplantbtn->Size = System::Drawing::Size(84, 29);
			this->addplantbtn->TabIndex = 0;
			this->addplantbtn->Text = L"Agregar";
			this->addplantbtn->UseVisualStyleBackColor = true;
			this->addplantbtn->Click += gcnew System::EventHandler(this, &PlantasForm::button1_Click);
			// 
			// deleteplantbtn
			// 
			this->deleteplantbtn->Location = System::Drawing::Point(492, 95);
			this->deleteplantbtn->Margin = System::Windows::Forms::Padding(3, 4, 3, 4);
			this->deleteplantbtn->Name = L"deleteplantbtn";
			this->deleteplantbtn->Size = System::Drawing::Size(84, 29);
			this->deleteplantbtn->TabIndex = 1;
			this->deleteplantbtn->Text = L"Eliminar";
			this->deleteplantbtn->UseVisualStyleBackColor = true;
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->PlantaName });
			this->dataGridView1->Location = System::Drawing::Point(29, 59);
			this->dataGridView1->Margin = System::Windows::Forms::Padding(3, 4, 3, 4);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(270, 188);
			this->dataGridView1->TabIndex = 2;
			this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &PlantasForm::dataGridView1_CellContentClick);
			// 
			// PlantaName
			// 
			this->PlantaName->HeaderText = L"Nombre";
			this->PlantaName->MinimumWidth = 6;
			this->PlantaName->Name = L"PlantaName";
			this->PlantaName->Width = 125;
			// 
			// btnIrASuelos
			// 
			this->btnIrASuelos->Location = System::Drawing::Point(575, 348);
			this->btnIrASuelos->Name = L"btnIrASuelos";
			this->btnIrASuelos->Size = System::Drawing::Size(145, 30);
			this->btnIrASuelos->TabIndex = 3;
			this->btnIrASuelos->Text = L"Configurar Suelo";
			this->btnIrASuelos->UseVisualStyleBackColor = true;
			this->btnIrASuelos->Click += gcnew System::EventHandler(this, &PlantasForm::btnIrASuelos_Click);
			// 
			// PlantasForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(759, 408);
			this->Controls->Add(this->btnIrASuelos);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->deleteplantbtn);
			this->Controls->Add(this->addplantbtn);
			this->Margin = System::Windows::Forms::Padding(3, 4, 3, 4);
			this->Name = L"PlantasForm";
			this->Text = L"PlantasForm";
			this->Load += gcnew System::EventHandler(this, &PlantasForm::PlantasForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void PlantasForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
		
	}
private: System::Void btnIrASuelos_Click(System::Object^ sender, System::EventArgs^ e) {

	SueloForm^ ventanaSuelos = gcnew SueloForm();
	ventanaSuelos->ShowDialog(); // Esto abre la ventana como emergente
}
};
}
